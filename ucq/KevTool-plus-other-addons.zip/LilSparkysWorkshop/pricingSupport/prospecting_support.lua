


-- prospecting support




local enabled = true


do
-- results : [ore][gem] = numProspected
	local prospectingResults = {
		[36912] = { --Saronite Ore
			[36929] = 0.275, --Huge Citrine
			[36930] = 0.04, --Monarch Topaz
			[36923] = 0.275, --Chalcedony
			[36924] = 0.04, --Sky Sapphire
			[36932] = 0.275, --Dark Jade
			[36918] = 0.06, --Scarlet Ruby
			[36926] = 0.275, --Shadow Crystal
			[36927] = 0.04, --Twilight Opal
			[36920] = 0.275, --Sun Crystal
			[36933] = 0.04, --Forest Emerald
			[36921] = 0.04, --Autumn\'s Glow
			[36917] = 0.275, --Bloodstone
		},
		[36909] = { --Cobalt Ore
			[36929] = 0.375, --Huge Citrine
			[36930] = 0.011, --Monarch Topaz
			[36923] = 0.375, --Chalcedony
			[36924] = 0.011, --Sky Sapphire
			[36932] = 0.375, --Dark Jade
			[36918] = 0.011, --Scarlet Ruby
			[36926] = 0.375, --Shadow Crystal
			[36927] = 0.011, --Twilight Opal
			[36920] = 0.375, --Sun Crystal
			[36917] = 0.375, --Bloodstone
			[36921] = 0.011, --Autumn\'s Glow
			[36933] = 0.011, --Forest Emerald
		},
		[10620] = { --Thorium Ore
			[12799] = 0.34, --Large Opal
			[23112] = 0.003, --Golden Draenite
			[23079] = 0.003, --Deep Peridot
			[12361] = 0.34, --Blue Sapphire
			[23117] = 0.003, --Azure Moonstone
			[12800] = 0.34, --Azerothian Diamond
			[23077] = 0.003, --Blood Garnet
			[21929] = 0.003, --Flame Spessarite
			[12364] = 0.34, --Huge Emerald
			[23107] = 0.003, --Shadow Draenite
			[7910] = 0.34, --Star Ruby
		},
		[36910] = { --Titanium Ore
			[36917] = 0.25, --Bloodstone
			[36918] = 0.04, --Scarlet Ruby
			[36919] = 0.04, --nil
			[36920] = 0.25, --Sun Crystal
			[36921] = 0.04, --Autumn\'s Glow
			[36922] = 0.04, --nil
			[36923] = 0.25, --Chalcedony
			[36924] = 0.04, --Sky Sapphire
			[36925] = 0.04, --nil
			[36926] = 0.25, --Shadow Crystal
			[36927] = 0.04, --Twilight Opal
			[36928] = 0.04, --nil
			[46849] = 0.867, --nil
			[36930] = 0.04, --Monarch Topaz
			[36931] = 0.05, --nil
			[36932] = 0.25, --Dark Jade
			[36933] = 0.04, --Forest Emerald
			[36934] = 0.04, --nil
			[36929] = 0.25, --Huge Citrine
		},
		[2772] = { --Iron Ore
			[3864] = 0.52, --Citrine
			[1529] = 0.52, --Jade
			[7909] = 0.05, --Aquamarine
			[1705] = 0.52, --Lesser Moonstone
			[7910] = 0.05, --Star Ruby
		},
		[2771] = { --Tin Ore
			[3864] = 0.033, --Citrine
			[1210] = 0.575, --Shadowgem
			[1529] = 0.033, --Jade
			[7909] = 0.033, --Aquamarine
			[1705] = 0.575, --Lesser Moonstone
			[1206] = 0.575, --Moss Agate
		},
		[2770] = { --Copper Ore
			[818] = 0.5, --Tigerseye
			[1210] = 0.1, --Shadowgem
			[774] = 0.50, --Malachite
		},
		[3858] = { --Mithril Ore
			[12364] = 0.025, --Huge Emerald
			[12361] = 0.025, --Blue Sapphire
			[3864] = 0.525, --Citrine
			[12800] = 0.025, --Azerothian Diamond
			[7909] = 0.525, --Aquamarine
			[7910] = 0.525, --Star Ruby
			[12799] = 0.025, --Large Opal
		},
		[23425] = { --Adamantite Ore
			[23441] = 0.033, --Nightseye
			[23438] = 0.033, --Star of Elune
			[23112] = 0.275, --Golden Draenite
			[23439] = 0.033, --Noble Topaz
			[23079] = 0.275, --Deep Peridot
			[23437] = 0.033, --Talasite
			[23117] = 0.275, --Azure Moonstone
			[23436] = 0.033, --Living Ruby
			[23440] = 0.033, --Dawnstone
			[21929] = 0.275, --Flame Spessarite
			[24243] = 1.0, --nil
			[23077] = 0.275, --Blood Garnet
			[23107] = 0.275, --Shadow Draenite
		},
		[23424] = { --Fel Iron Ore
			[23441] = 0.01, --Nightseye
			[23438] = 0.01, --Star of Elune
			[23112] = 0.267, --Golden Draenite
			[23439] = 0.01, --Noble Topaz
			[23437] = 0.01, --Talasite
			[23117] = 0.267, --Azure Moonstone
			[23436] = 0.01, --Living Ruby
			[23440] = 0.01, --Dawnstone
			[21929] = 0.267, --Flame Spessarite
			[23079] = 0.267, --Deep Peridot
			[23077] = 0.267, --Blood Garnet
			[23107] = 0.267, --Shadow Draenite
		},
	}

	local prospectingLevels = {
		[36912] = { "playerProspectLevel", 400}, --Saronite Ore
		[36909] = { "playerProspectLevel", 350}, --Cobalt Ore
		[23425] = { "playerProspectLevel", 325}, --Adamantite Ore
		[23424] = { "playerProspectLevel", 275}, --Fel Iron Ore
		[10620] = { "playerProspectLevel", 250}, --Thorium Ore
		[3858] = { "playerProspectLevel", 175}, --Mithril Ore
		[2772] = { "playerProspectLevel", 125}, -- Iron Ore
		[2771] = { "playerProspectLevel", 50}, --Tin Ore
		[2770] = { "playerProspectLevel", 20}, --Copper Ore
	}


	-- spoof recipes for prospected ores -> gems
	local function AddToRecipeCache()
		for oreID, gemTable in pairs(prospectingResults) do
			local reagentTable = {}
			local recipeName = "Prospect "..(GetItemInfo(oreID) or "item:"..oreID)

			reagentTable[oreID] = 5

			LSW:AddRecipe(-oreID, recipeName, gemTable, reagentTable, prospectingLevels[oreID])
		end
	end

	local function Init()
--		LSW:ChatMessage("LilSparky's Workshop adding native Prospecting support")

		AddToRecipeCache()
	end


	local function Test(index)
		if enabled then
			return true
		end

		return false
	end

	LSW:RegisterPricingSupport("Prospecting", Test, Init)
end


